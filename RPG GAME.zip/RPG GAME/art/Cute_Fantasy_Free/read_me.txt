Hello! Thank you for downloading the Cute Fantasy asset pack.

This project will be getting updates over time. This version of the asset pack is not final and there will be few more additional sprites.
	
License - Free Version
   - You can use these assets in non-commercial projects.
   - You can modify the assets.
   - You can not redistribute or resale, even if modified

If you like the asset pack leave a comment. It helps to support the asset pack and get more people to see it. Thanks!